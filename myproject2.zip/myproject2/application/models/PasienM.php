<?php

class PasienM extends CI_Model {
    public $id, $user, $kode, $gender, $tmp_lahir, $tgl_lahir;
   

    // rujukan untuk pasien
}

