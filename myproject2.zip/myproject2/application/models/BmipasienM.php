<?php

class BmipasienM extends CI_Model {
    public $id, $tanggal_periksa, $user, $bmi;
    
    // public function jenisKelamin() {
    //     return $this->gender=="L" ? "Laki-laki" : "Perempuan";
    // }   

    // rujukan untuk bmipasien  
}